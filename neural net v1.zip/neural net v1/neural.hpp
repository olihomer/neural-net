//
//  neural.hpp
//  neural net v1
//
//  Created by Oliver Homer on 27/02/2024.
//

#ifndef neural_hpp
#define neural_hpp

#include <stdio.h>
#include <vector>
#include <iostream>
#include "data_set.hpp"


struct layer
{
    int size;
    std::vector<double> weighted_input;
    std::vector<double> error;
    std::vector<double> training_error;

    std::vector<double> value;
    std::vector<double> bias;
    std::vector<std::vector<double>> weight;
    std::vector<std::vector<double>> scaled_weight_error;
};

class neural
{
public:
    
    //Constructor
    neural(std::vector<int> nodes_per_layer);
    
    //Debug
    void print_dimensions(std::ostream& stream);
    void print_weights(std::ostream& stream);
    void print_biases(std::ostream& stream);
    void print_values(std::ostream& stream);
    void print_errors(std::ostream& stream);
    void print_training_errors(std::ostream& stream);
    void print_network(std::ostream& stream);
    
    //Getters + setters
    void set_input(int node, double value);
    void set_input(data_set& data,int index);
    void set_bias(int layer, std::vector<double>bias);
    void set_weight(int layer, int node, std::vector<double>weight);
    double get_output(int node);
    int find_highest_output(void);

    //Statics
    static double sigmoid(double x){return (1/(1+exp(-x)));}
    static double sigmoid_prime(double x){double z = sigmoid(x);return z*(1-z);}
    const double learning_rate = 0.005;
    
    //Public methods
    void propogate();
    void gradient_descent();
    void train(data_set training_data);
    
private:
    // Internal data structure
    int m_layers = 0;
    int m_max_layers = 0;
    std::vector<layer> m_layer;

    //Internal methods
    double cost_function(std::vector<double> target);
    void zero_training_error();

};






#endif /* neural_hpp */
